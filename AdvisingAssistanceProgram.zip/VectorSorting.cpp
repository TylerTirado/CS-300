//============================================================================
// Name        : AdvisingAssistanceProgram
// Author      : Tyler Tirado
// Version     : 1.0
// Description : Project 2 - Advising Assistance Program
//============================================================================

#include <algorithm>
#include <iostream>
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations

// define a structure to hold bid information
struct Bid {
    string courseId; // unique identifier
    string courseName;
    string preReq1;
    string preReq2;

    Bid() {
       
    }
};

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
    cout << bid.courseId << ": " << bid.courseName << " | " << bid.preReq1 << " | "
        << bid.preReq2 << endl;
    return;
}

/**
 * Prompt user for bid information using console (std::in)
 *
 * @return Bid struct containing the bid info
 */
Bid getBid() {
    Bid bid;

    cout << "Enter Id: ";
    cin.ignore();
    getline(cin, bid.courseId);

    cout << "Enter course Name: ";
    getline(cin, bid.courseName);

    cout << "Enter pre req course: ";
    getline(cin, bid.preReq1);

    cout << "Enter pre req course 2: ";
    getline(cin, bid.preReq2);
    cin.ignore();
    
    return bid;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
vector<Bid> loadBids(string csvPath) {
    cout << "Loading CSV file " << csvPath << endl;

    // Define a vector data structure to hold a collection of bids.
    vector<Bid> bids;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    try {
        // loop to read rows of a CSV file
        for (int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Bid bid;
            bid.courseId = file[i][0];
            bid.courseName = file[i][1];
            bid.preReq1 = file[i][2];
            bid.preReq2 = file[i][3];

            //cout << "Item: " << bid.title << ", Fund: " << bid.fund << ", Amount: " << bid.amount << endl;

            // push this bid to the end
            bids.push_back(bid);
        }
    }
    catch (csv::Error& e) {
        std::cerr << e.what() << std::endl;
    }
    return bids;
}



/**
 * Partition the vector of bids into two parts, low and high
 *
 * @param bids Address of the vector<Bid> instance to be partitioned
 * @param begin Beginning index to partition
 * @param end Ending index to partition
 */
int partition(vector<Bid>& bids, int begin, int end) {
    //set low and high equal to begin and end
    int low = begin;
    int high = end;

    // pick the middle element as pivot point
    int pivot = low + (high - low) / 2;

    // while not done 
    bool done = false;
    while (!done) {
        while (bids[low].courseName < bids[pivot].courseName) {
            ++low;
            // keep incrementing low index while bids[low] < bids[pivot]
        }
        while (bids[pivot].courseName < bids[high].courseName) {
            --high;
        }
        // keep decrementing high index while bids[pivot] < bids[high]


        /* If there are zero or one elements remaining,
            all bids are partitioned. Return high */
            // else swap the low and high bids (built in vector method)        
        if (low >= high) {
            done = true;
        }
        else {
            swap(bids[low], bids[high]);
            // move low and high closer ++low, --high
            ++low;
            --high;
        }
        //return high;
        return high;
    }
}

/**
 * Perform a quick sort on bid title
 * Average performance: O(n log(n))
 * Worst case performance O(n^2))
 *
 * @param bids address of the vector<Bid> instance to be sorted
 * @param begin the beginning index to sort on
 * @param end the ending index to sort on
 */
void quickSort(vector<Bid>& bids, int begin, int end) {
    unsigned int mid = 0;
    //set mid equal to 0
    if (begin >= end) {
        return;
    }
    /* Base case: If there are 1 or zero bids to sort,
     partition is already sorted otherwise if begin is greater
     than or equal to end then return*/
    mid = partition(bids, begin, end);

    /* Partition bids into low and high such that
     midpoint is location of last element in low */

     // recursively sort low partition (begin to mid)
    quickSort(bids, begin, mid);
    // recursively sort high partition (mid+1 to end)
    quickSort(bids, mid + 1, end);
}

// FIXME (1a): Implement the selection sort logic over bid.title

/**
 * Perform a selection sort on bid title
 * Average performance: O(n^2))
 * Worst case performance O(n^2))
 *
 * @param bid address of the vector<Bid>
 *            instance to be sorted
 */


/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        break;
    default:
        csvPath = "eBid_Monthly_Sales.csv";
    }

    // Define a vector to hold all the bids
    vector<Bid> bids;

    // Define a timer variable
    clock_t ticks;

    string courseName;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Course Data File" << endl;
        cout << "  2. Display All Courses" << endl;
        cout << "  3. Display Course" << endl;
        cout << "  4. Quick Sort All Courses" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            // Initialize a timer variable before loading bids
            ticks = clock();

            // Complete the method call to load the bids
            cout << "enter course data file name..." << endl;
            cin >> csvPath;
            bids = loadBids(csvPath);

            cout << bids.size() << " bids read" << endl;

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 2:
            // Loop and display the bids read
            for (int i = 0; i < bids.size(); ++i) {
                displayBid(bids[i]);
            }
            cout << endl;

            break;

           
        case 3:
            ticks = clock();
            //enter the course name you wish to search
            cout << "enter course name: " << endl;
            cin >> courseName;
            for (int i = 0; i < bids.size(); ++i) {
                

                displayBid(bids[i]);
            }
            cout << endl;

            ticks = clock() - ticks;
            cout << "time: " << ticks << " clock ticks." << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds." << endl;

            break;

           //Invoke the quick sort and report timing results
        case 4:
            ticks = clock();

            quickSort(bids, 0, bids.size() - 1);
            cout << bids.size() << " bids read." << endl;

            ticks = clock() - ticks;
            cout << "time: " << ticks << " clock ticks." << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds." << endl;

            break;
        }
    }

    cout << "Good bye." << endl;

    return 0;
}

